'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class collectedbeers extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      collectedbeers.belongsTo(models.users, { foreignKey: 'user_id' });
      collectedbeers.belongsTo(models.beers, { foreignKey: 'beer_id' });
    }
  }
  collectedbeers.init({
    collected_beer_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    collected_date: DataTypes.DATE,
    points_awarded: DataTypes.INTEGER,
    user_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'user_id'
      }
    },
    beer_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'beers',
        key: 'beer_id'
      }
    }
  }, {
    sequelize,
    modelName: 'collectedbeers',
    tableName: 'collectedbeers',
    timestamps: false
  });
  return collectedbeers;
};
