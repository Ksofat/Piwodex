const router = require('express').Router();
const models = require('../db/models');
const bcrypt = require('bcryptjs');

// Create a new user
router.post("/users", async (req, res) => {
    const { Nickname, Email, Password, UserType } = req.body;
    const hashedPassword = await bcrypt.hash(Password, 10);
    models.Users.create({
        Nickname,
        Email,
        Password: hashedPassword,
        CreatedDate: new Date(),
        UserType
    }).then((user) => {
        res.status(201).json({ UserID: user.UserID, Nickname: user.Nickname, Email: user.Email, UserType: user.UserType });
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Retrieve all users
router.get("/users", (req, res) => {
    models.Users.findAll()
    .then(users => {
        res.json(users);
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

// Retrieve a single user by ID
router.get("/users/:id", (req, res) => {
    const { id } = req.params;
    models.Users.findByPk(id)
    .then(user => {
        if (user) {
            res.json(user);
        } else {
            res.status(404).send('User not found');
        }
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

// Update a user
router.put("/users/:id", async (req, res) => {
    const { id } = req.params;
    const { Nickname, Email, Password, UserType } = req.body;
    let updatedData = { Nickname, Email, UserType };
    if (Password) {
        updatedData.Password = await bcrypt.hash(Password, 10);
    }
    models.Users.update(updatedData, { where: { UserID: id } })
    .then(() => {
        res.send("User updated successfully");
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

// Delete a user
router.delete("/users/:id", (req, res) => {
    const { id } = req.params;
    models.Users.destroy({
        where: { UserID: id }
    })
    .then(() => {
        res.send("User deleted successfully");
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

module.exports = router;