const router = require('express').Router();
const models = require('../db/models');

// Create a new achievement
router.post("/achievements", (req, res) => {
    const { description, tier_required } = req.body;
    models.achievements.create({
        description,
        tier_required
    }).then((achievement) => {
        res.status(201).json(achievement);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get all achievements
router.get("/achievements", (req, res) => {
    models.achievements.findAll()
    .then((achievements) => {
        res.json(achievements);
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

// Get a single achievement by ID
router.get("/achievements/:id", (req, res) => {
    const { id } = req.params;
    models.achievements.findByPk(id)
    .then((achievement) => {
        if (achievement) {
            res.json(achievement);
        } else {
            res.status(404).send('Achievement not found');
        }
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

// Update an achievement by ID
router.put("/achievements/:id", (req, res) => {
    const { id } = req.params;
    const { description, tier_required } = req.body;
    models.achievements.update({
        Description, tier_required
    }, {
        where: { achievement_id }
    }).then(() => {
        res.send("Achievement updated successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

// Delete an achievement by ID
router.delete("/achievements/:id", (req, res) => {
    const { id } = req.params;
    models.achievements.destroy({
        where: { achievement_id }
    }).then(() => {
        res.send("Achievement deleted successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

module.exports = router;