const router = require('express').Router();
const models = require('../db/models');

// Create a new beer
router.post("/beers", (req, res) => {
    const { beer_name, bar_code, tier, beer_image, alcohol_content } = req.body;
    models.beers.create({
        beer_name,
        bar_code,
        tier,
        beer_image,
        alcohol_content
    }).then((beer) => {
        res.status(201).json(beer);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get all beers
router.get("/beers", (req, res) => {
    models.beers.findAll()
    .then((beers) => {
        res.json(beers);
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

// Get a single beer by ID
router.get("/beers/:id", (req, res) => {
    const { id } = req.params;
    models.beers.findByPk(id)
    .then((beer) => {
        if (beer) {
            res.json(beer);
        } else {
            res.status(404).send('Beer not found');
        }
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

// Update a beer by ID
router.put("/beers/:id", (req, res) => {
    const { id } = req.params;
    const { beer_name, bar_code, tier, beer_image, alcohol_content } = req.body;
    models.beers.update({
        beer_name, bar_code, tier, beer_image, alcohol_content
    }, {
        where: { beer_id }
    }).then(() => {
        res.send("Beer updated successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

// Delete a beer by ID
router.delete("/beers/:id", (req, res) => {
    const { id } = req.params;
    models.beers.destroy({
        where: { beer_id }
    }).then(() => {
        res.send("Beer deleted successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    })
});

module.exports = router;