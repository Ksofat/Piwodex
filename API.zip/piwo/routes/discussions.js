const router = require('express').Router();
const models = require('../db/models');

// Create a new discussion
router.post("/discussions", (req, res) => {
    const { Message, ModifiedDate, UserID, StoreID } = req.body;
    models.Discussions.create({
        Message,
        ModifiedDate: new Date(ModifiedDate),
        UserID,
        StoreID
    }).then((discussion) => {
        res.status(201).json(discussion);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get all discussions
router.get("/discussions", (req, res) => {
    models.Discussions.findAll()
    .then((discussions) => {
        res.json(discussions);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get a single discussion by ID
router.get("/discussions/:id", (req, res) => {
    const { id } = req.params;
    models.Discussions.findByPk(id)
    .then((discussion) => {
        if (discussion) {
            res.json(discussion);
        } else {
            res.status(404).send('Discussion not found');
        }
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Update a discussion by ID
router.put("/discussions/:id", (req, res) => {
    const { id } = req.params;
    const { Message, ModifiedDate, UserID, StoreID } = req.body;
    models.Discussions.update({
        Message,
        ModifiedDate: new Date(ModifiedDate),
        UserID,
        StoreID
    }, {
        where: { DiscussionID: id }
    }).then(() => {
        res.send("Discussion updated successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Delete a discussion by ID
router.delete("/discussions/:id", (req, res) => {
    const { id } = req.params;
    models.Discussions.destroy({
        where: { DiscussionID: id }
    }).then(() => {
        res.send("Discussion deleted successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

module.exports = router;