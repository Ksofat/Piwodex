const router = require('express').Router();
const models = require('../db/models');

// Create a new user achievement
router.post("/userAchievements", (req, res) => {
    const { user_id, achievement_id } = req.body;
    models.userachievements.create({
        achived_date: new Date(),
        user_id,
        achievement_id
    }).then((userAchievement) => {
        res.status(201).json(userAchievement);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get all user achievements
router.get("/userAchievements", (req, res) => {
    models.userachievements.findAll()
    .then((userAchievements) => {
        res.json(userAchievements);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get a single user achievement by ID
router.get("/userAchievements/:id", (req, res) => {
    const { id } = req.params;
    models.userachievements.findByPk(id)
    .then((userAchievement) => {
        if (userAchievement) {
            res.json(userAchievement);
        } else {
            res.status(404).send('User Achievement not found');
        }
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Update a user achievement by ID
router.put("/userAchievements/:id", (req, res) => {
    const { id } = req.params;
    const { achived_date, user_id, achievement_id } = req.body;
    models.userachievements.update({
        achived_date, user_id, achievement_id
    }, {
        where: { user_achievement_id: id }
    }).then(() => {
        res.send("User Achievement updated successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Delete a user achievement by ID
router.delete("/userAchievements/:id", (req, res) => {
    const { id } = req.params;
    models.userachievements.destroy({
        where: { user_achievement_id: id }
    }).then(() => {
        res.send("User Achievement deleted successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

module.exports = router;