const router = require('express').Router();
const models = require('../db/models');

// Create a new discussion
router.post("/discussions", (req, res) => {
    const { message, modified_date, user_id, store_id } = req.body;
    models.discussions.create({
        message,
        modified_date: new Date(modified_date),
        user_id,
        store_id
    }).then((discussion) => {
        res.status(201).json(discussion);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get all discussions
router.get("/discussions", (req, res) => {
    models.discussions.findAll()
    .then((discussions) => {
        res.json(discussions);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get a single discussion by ID
router.get("/discussions/:id", (req, res) => {
    const { id } = req.params;
    models.discussions.findByPk(id)
    .then((discussion) => {
        if (discussion) {
            res.json(discussion);
        } else {
            res.status(404).send('Discussion not found');
        }
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Update a discussion by ID
router.put("/discussions/:id", (req, res) => {
    const { id } = req.params;
    const { message, modified_date, user_id, store_id } = req.body;
    models.discussions.update({
        message,
        modified_date: new Date(modified_date),
        user_id,
        store_id
    }, {
        where: { discussion_id: id }
    }).then(() => {
        res.send("Discussion updated successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Delete a discussion by ID
router.delete("/discussions/:id", (req, res) => {
    const { id } = req.params;
    models.discussions.destroy({
        where: { discussion_id: id }
    }).then(() => {
        res.send("Discussion deleted successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

module.exports = router;