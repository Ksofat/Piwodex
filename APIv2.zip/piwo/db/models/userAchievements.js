'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class userachievements extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // Define associations here
      userachievements.belongsTo(models.users, { foreignKey: 'user_id' });
      userachievements.belongsTo(models.achievements, { foreignKey: 'achievement_id' });
    }
  }
  userachievements.init({
    user_achievement_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    achived_date: DataTypes.DATE,
    user_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'user_id'
      }
    },
    achievement_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'achievements',
        key: 'achievement_id'
      }
    }
  }, {
    sequelize,
    modelName: 'userachievements',
    tableName: 'userachievements',
    timestamps: false
  });
  return userachievements;
};