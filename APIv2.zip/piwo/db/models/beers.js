'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class beers extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      beers.hasMany(models.collectedbeers, { foreignKey: 'beer_id' });
    }
  }
  beers.init({
    beer_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    beer_name: DataTypes.STRING,
    bar_code: DataTypes.STRING,
    tier: DataTypes.STRING,
    beer_image: DataTypes.BLOB,
    alcohol_content: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'beers',
    tableName: 'beers', // Ensure the table name is correctly specified if it's case-sensitive
    timestamps: false // Assuming no createdAt or updatedAt columns
  });
  return beers;
};
