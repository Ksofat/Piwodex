const router = require('express').Router();
const models = require('../db/models');

// Create a new store
router.post("/stores", (req, res) => {
    const { StoreName, LocationX, LocationY } = req.body;
    models.Stores.create({
        StoreName,
        LocationX,
        LocationY
    }).then((store) => {
        res.status(201).json(store);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get all stores
router.get("/stores", (req, res) => {
    models.Stores.findAll()
    .then((stores) => {
        res.json(stores);
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Get a single store by ID
router.get("/stores/:id", (req, res) => {
    const { id } = req.params;
    models.Stores.findByPk(id)
    .then((store) => {
        if (store) {
            res.json(store);
        } else {
            res.status(404).send('Store not found');
        }
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Update a store by ID
router.put("/stores/:id", (req, res) => {
    const { id } = req.params;
    const { StoreName, LocationX, LocationY } = req.body;
    models.Stores.update({
        StoreName, LocationX, LocationY
    }, {
        where: { StoreID: id }
    }).then(() => {
        res.send("Store updated successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

// Delete a store by ID
router.delete("/stores/:id", (req, res) => {
    const { id } = req.params;
    models.Stores.destroy({
        where: { StoreID: id }
    }).then(() => {
        res.send("Store deleted successfully");
    }).catch((err) => {
        res.status(500).send(err.message);
    });
});

module.exports = router;