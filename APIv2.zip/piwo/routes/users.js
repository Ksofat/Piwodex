const router = require('express').Router();
const models = require('../db/models');
const bcrypt = require('bcryptjs');

// Create a new user
router.post("/users", async (req, res) => {
    try {
        const { nickname, email, password, user_type } = req.body;

        // Validate input (you can add more comprehensive validation as needed)
        if (!nickname || !email || !password) {
            return res.status(400).send('fields are required');
        }

        // Check for existing user
        const existingUser = await models.users.findOne({ where: { email } });
        if (existingUser) {
            return res.status(409).send('User with this email already exists');
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = await models.users.create({
            nickname,
            email,
            password: hashedPassword,
            created_date: new Date(),
            user_type
        }, { exclude: ['user_id'] });

        res.status(201).json({
            user_id: newUser.user_id,
            nickname: newUser.nickname,
            email: newUser.email,
            user_type: newUser.user_type
        });

    } catch (err) {
        console.error(err);
        res.status(500).send(err.message);
    }
});

// Retrieve all users
router.get("/users", (req, res) => {
    models.users.findAll()
    .then(users => {
        res.json(users);
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

// Retrieve a single user by ID
router.get("/users/:id", (req, res) => {
    const { id } = req.params;
    models.users.findByPk(id)
    .then(user => {
        if (user) {
            res.json(user);
        } else {
            res.status(404).send('User not found');
        }
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

// Update a user
router.put("/users/:id", async (req, res) => {
    const { id } = req.params;
    const { nickname, email, Password, user_type } = req.body;
    let updatedData = { nickname, email, user_type };
    if (Password) {
        updatedData.Password = await bcrypt.hash(Password, 10);
    }
    models.users.update(updatedData, { where: { user_id: id } })
    .then(() => {
        res.send("User updated successfully");
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

// Delete a user
router.delete("/users/:id", (req, res) => {
    const { id } = req.params;
    models.users.destroy({
        where: { user_id: id }
    })
    .then(() => {
        res.send("User deleted successfully");
    })
    .catch(err => {
        res.status(500).send(err.message);
    });
});

module.exports = router;